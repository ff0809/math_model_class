MMCTR Task 1 代码与报告说明

目录内容

ctr/                  官方 DIN 的训练、验证和预测代码
embedding_extraction/ 多模态 item embedding 提取代码
report/               Task 1 实验报告

一、数据目录

数据文件不包含在代码包中。运行 CTR 实验前，需要在 ctr/ 下准备：

data/MicroLens_1M_x1/train.parquet
data/MicroLens_1M_x1/valid.parquet
data/MicroLens_1M_x1/test.parquet
data/MicroLens_1M_x1/item_info.parquet
data/MicroLens_1M_x1/item_info_ziao.parquet

二、官方 item embedding + DIN

cd ctr
python run_param_tuner.py \
  --config config/DIN_microlens_mmctr_tuner_config_01_bs4096.yaml \
  --gpu 0

三、多模态 item embedding 提取

提取过程需要本地 Jina-CLIP-v2 权重、item_feature.parquet 和 item_images/。
具体参数见 embedding_extraction/README.md。

提取结果为 item_info_updated.parquet。用于 CTR 实验时，将其放置为：

ctr/data/MicroLens_1M_x1/item_info_ziao.parquet

四、多模态 item embedding + DIN

cd ctr
python run_param_tuner.py \
  --config config/DIN_microlens_mmctr_ziao_bs4096.yaml \
  --gpu 0

五、测试集预测

训练完成后，根据结果 CSV 选择验证集 AUC 最高的 expid：

python prediction.py \
  --config config/DIN_microlens_mmctr_ziao_bs4096 \
  --expid <BEST_EXPID> \
  --gpu 0

脚本将在 submission/ 下生成 prediction.csv 和对应的 zip 提交文件。
