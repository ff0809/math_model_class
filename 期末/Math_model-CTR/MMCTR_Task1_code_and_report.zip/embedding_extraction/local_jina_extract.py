#!/usr/bin/env python3

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.decomposition import PCA
from tqdm import tqdm
from transformers import AutoModel


WEIGHT_SUFFIXES = {".bin", ".pt", ".pth", ".safetensors"}


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-path", type=Path, default=Path("weights/jina-clip-v2"))
    parser.add_argument("--item-feature", type=Path, default=Path("item_feature.parquet"))
    parser.add_argument("--item-info", type=Path, default=Path("data/item_info.parquet"))
    parser.add_argument("--image-dir", type=Path, default=Path("item_images"))
    parser.add_argument("--output", type=Path, default=Path("data/item_info_updated.parquet"))
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--image-weight", type=float, default=0.8)
    parser.add_argument("--text-weight", type=float, default=0.2)
    parser.add_argument("--pca-dim", type=int, default=128)
    parser.add_argument("--seed", type=int, default=20242025)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def sha256_file(path, chunk_size=8 * 1024 * 1024):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def to_numpy(value):
    if torch.is_tensor(value):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def collect_items(item_feature_path, image_dir):
    item_feature = pd.read_parquet(item_feature_path)
    required = {"item_id", "item_title"}
    missing = required.difference(item_feature.columns)
    if missing:
        raise ValueError(f"Missing item_feature columns: {sorted(missing)}")
    if item_feature["item_id"].duplicated().any():
        raise ValueError("item_feature contains duplicate item_id values")

    title_by_id = item_feature.set_index("item_id")["item_title"].to_dict()
    items = []
    for image_path in image_dir.glob("*.jpg"):
        try:
            item_id = int(image_path.stem)
        except ValueError as error:
            raise ValueError(f"Image filename is not an integer item_id: {image_path}") from error
        if item_id not in title_by_id:
            raise ValueError(f"No item_title found for item_id={item_id}")
        items.append((item_id, image_path, str(title_by_id[item_id])))
    items.sort(key=lambda row: row[0])
    if not items:
        raise ValueError(f"No .jpg images found under {image_dir}")
    return items


def extract_embeddings(model, items, batch_size):
    image_parts = []
    text_parts = []
    for offset in tqdm(range(0, len(items), batch_size), desc="Extracting"):
        batch = items[offset : offset + batch_size]
        image_paths = [str(row[1]) for row in batch]
        titles = [row[2] for row in batch]
        with torch.inference_mode():
            image_parts.append(to_numpy(model.encode_image(image_paths)))
            text_parts.append(to_numpy(model.encode_text(titles)))
    return np.concatenate(image_parts), np.concatenate(text_parts)


def write_item_info(item_info_path, output_path, items, embeddings):
    item_info = pd.read_parquet(item_info_path)
    required = {"item_id", "item_emb_d128"}
    missing = required.difference(item_info.columns)
    if missing:
        raise ValueError(f"Missing item_info columns: {sorted(missing)}")

    embedding_by_id = {
        item_id: embedding.astype(np.float64)
        for (item_id, _, _), embedding in zip(items, embeddings)
    }
    target_ids = set(int(value) for value in item_info["item_id"] if int(value) != 0)
    missing_ids = target_ids.difference(embedding_by_id)
    extra_ids = set(embedding_by_id).difference(target_ids)
    if missing_ids or extra_ids:
        raise ValueError(
            "Image/item_info coverage mismatch: "
            f"missing={len(missing_ids)}, extra={len(extra_ids)}"
        )

    item_info["item_emb_d128"] = [
        old_embedding if int(item_id) == 0 else embedding_by_id[int(item_id)]
        for item_id, old_embedding in zip(
            item_info["item_id"], item_info["item_emb_d128"]
        )
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    item_info.to_parquet(output_path, engine="pyarrow", index=False)


def build_manifest(args, items, image_embeddings, output_path):
    weight_files = sorted(
        path
        for path in args.model_path.rglob("*")
        if path.is_file() and path.suffix.lower() in WEIGHT_SUFFIXES
    )
    return {
        "status": "completed",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "method": "Jina-CLIP-v2 local inference, 0.8 image + 0.2 text, PCA-128",
        "command": sys.argv,
        "model_path": str(args.model_path.resolve()),
        "model_weight_files": [
            {
                "path": str(path.resolve()),
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for path in weight_files
        ],
        "inputs": {
            "item_feature": {
                "path": str(args.item_feature.resolve()),
                "sha256": sha256_file(args.item_feature),
            },
            "item_info": {
                "path": str(args.item_info.resolve()),
                "sha256": sha256_file(args.item_info),
            },
            "image_dir": str(args.image_dir.resolve()),
        },
        "parameters": {
            "device": args.device,
            "batch_size": args.batch_size,
            "image_weight": args.image_weight,
            "text_weight": args.text_weight,
            "pca_dim": args.pca_dim,
            "seed": args.seed,
        },
        "counts": {
            "items": len(items),
            "raw_embedding_dim": int(image_embeddings.shape[1]),
            "output_embedding_dim": args.pca_dim,
        },
        "output": {
            "path": str(output_path.resolve()),
            "sha256": sha256_file(output_path),
        },
    }


def main():
    args = parse_args()
    if not np.isclose(args.image_weight + args.text_weight, 1.0):
        raise ValueError("image_weight + text_weight must equal 1")
    if not args.model_path.exists():
        raise FileNotFoundError(args.model_path)
    if args.output.exists() and not args.overwrite:
        raise FileExistsError(
            f"{args.output} already exists; pass --overwrite to replace it"
        )
    if not torch.cuda.is_available() and args.device.startswith("cuda"):
        raise RuntimeError("CUDA device requested but CUDA is unavailable")

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    items = collect_items(args.item_feature, args.image_dir)

    model = AutoModel.from_pretrained(
        str(args.model_path),
        trust_remote_code=True,
        local_files_only=True,
    )
    model.to(torch.device(args.device))
    model.eval()

    image_embeddings, text_embeddings = extract_embeddings(
        model, items, args.batch_size
    )
    if image_embeddings.shape != text_embeddings.shape:
        raise ValueError(
            f"Image/text shape mismatch: {image_embeddings.shape} vs "
            f"{text_embeddings.shape}"
        )

    fused = (
        image_embeddings * args.image_weight
        + text_embeddings * args.text_weight
    )
    reduced = PCA(
        n_components=args.pca_dim,
        random_state=args.seed,
    ).fit_transform(fused)
    write_item_info(args.item_info, args.output, items, reduced)

    manifest_path = args.manifest or args.output.with_suffix(".manifest.json")
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest = build_manifest(args, items, image_embeddings, args.output)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    print(f"Wrote {args.output}")
    print(f"Wrote {manifest_path}")


if __name__ == "__main__":
    main()
