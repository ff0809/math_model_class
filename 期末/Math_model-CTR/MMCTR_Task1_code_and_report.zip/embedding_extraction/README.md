# 多模态 embedding 提取

## 输入

```text
weights/jina-clip-v2/
item_feature.parquet
item_images/
data/item_info.parquet
```

## 处理流程

1. 从本地目录加载 Jina-CLIP-v2 权重。
2. 按 item_id 读取图片和标题并提取特征。
3. 按 0.8 * image + 0.2 * text 融合特征。
4. 使用 PCA 将特征降至 128 维。
5. 按 item_id 写入 item_emb_d128。

## 运行

```bash
cd ZiaoGao_MMCTR

/root/miniconda3/condabin/conda run -p /sport/envs/mmctr \
  python reproduction/local_jina_extract.py \
  --model-path weights/jina-clip-v2 \
  --item-feature item_feature.parquet \
  --item-info data/item_info.parquet \
  --image-dir item_images \
  --output data/item_info_updated.parquet \
  --device cuda:0 \
  --overwrite
```

输出：

```text
data/item_info_updated.parquet
data/item_info_updated.manifest.json
```
