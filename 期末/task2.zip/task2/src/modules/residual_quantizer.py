import numpy as np
import torch
from sklearn.cluster import KMeans


class ResidualQuantizer:
    def __init__(self, num_clusters=5, num_layers=3):
        self.num_clusters = num_clusters
        self.num_layers = num_layers
        self.codebooks = []
        self.layer_all_embeddings = []
        self.layer_all_item_ids = []

        self.codebooks_tensor = []
        self.layer_all_embeddings_tensor = []
        self.layer_all_item_ids_tensor = []

    def fit(self, X, item_ids):
        residual = X.copy()
        current_item_ids = item_ids.copy()

        self.codebooks = []
        self.layer_all_embeddings = []
        self.layer_all_item_ids = []

        for layer in range(self.num_layers):
            kmeans = KMeans(n_clusters=self.num_clusters, n_init='auto', random_state=20242025)
            kmeans.fit(residual)
            centers = kmeans.cluster_centers_
            labels = kmeans.labels_
            self.codebooks.append(centers)

            embeddings_list = []
            item_ids_list = []
            for cluster_id in range(self.num_clusters):
                indices = np.where(labels == cluster_id)[0]
                if len(indices) > 0:
                    embeddings_list.append(residual[indices])
                    item_ids_list.append(current_item_ids[indices])

            layer_embeddings = np.concatenate(embeddings_list, axis=0)
            layer_item_ids = np.concatenate(item_ids_list, axis=0)
            self.layer_all_embeddings.append(layer_embeddings)
            self.layer_all_item_ids.append(layer_item_ids)

            residual = residual - centers[labels]

        self.codebooks_tensor = [torch.tensor(cb, dtype=torch.float32) for cb in self.codebooks]
        self.layer_all_embeddings_tensor = [torch.tensor(emb, dtype=torch.float32) for emb in self.layer_all_embeddings]
        self.layer_all_item_ids_tensor = [torch.tensor(ids, dtype=torch.long) for ids in self.layer_all_item_ids]

    def quantize(self, X):
        with torch.no_grad():
            residual = X
            quantized_ids = []
            for layer in range(self.num_layers):
                all_emb = self.layer_all_embeddings_tensor[layer].to(X.device)
                all_item_ids = self.layer_all_item_ids_tensor[layer].to(X.device)

                dists = torch.cdist(residual.float(), all_emb.float())
                min_indices = torch.argmin(dists, dim=1)

                selected_item_ids = all_item_ids[min_indices]
                quantized_ids.append(selected_item_ids)

                centers = self.codebooks_tensor[layer].to(X.device)
                candidate = all_emb[min_indices]

                d_cluster = torch.cdist(candidate.float().unsqueeze(0), centers.float().unsqueeze(0)).squeeze(0)
                selected_cluster = torch.argmin(d_cluster, dim=1)
                selected_center = centers[selected_cluster]
                residual = residual - selected_center
            return quantized_ids
