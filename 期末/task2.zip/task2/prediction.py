import os
os.chdir(os.path.dirname(os.path.realpath(__file__)))
import sys
import logging
import fuxictr_version
from datetime import datetime
import argparse
from pathlib import Path
import pandas as pd
import shutil
from src.runtime import prepare_experiment, make_rank_iterator


if __name__ == '__main__':
    ''' Usage: python run_expid.py --config {config_dir} --expid {experiment_id} --gpu {gpu_device_id}
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='./config/', help='The config directory.')
    parser.add_argument('--expid', type=str, default='DeepFM_test', help='The experiment id to run.')
    parser.add_argument('--gpu', type=int, default=-1, help='The gpu index, -1 for cpu')
    args = vars(parser.parse_args())
    
    experiment_id = args['expid']
    params, feature_map, model = prepare_experiment(args['config'], experiment_id, args['gpu'])
    model.load_weights(model.checkpoint)

    logging.info('Test scoring...')
    test_gen = make_rank_iterator(feature_map, params, stage='test')
    test_pred = model.predict(test_gen)
    ans = pd.DataFrame({"ID": range(test_pred.shape[0]),
                        "Task1": test_pred})
    
    logging.info("Writing results...")
    os.makedirs("submission", exist_ok=True)
    ans.to_csv("submission/prediction.csv", index=False)
    shutil.make_archive(f'submission/{experiment_id}', 'zip', 'submission/', 'prediction.csv')
    logging.info("All done.")
